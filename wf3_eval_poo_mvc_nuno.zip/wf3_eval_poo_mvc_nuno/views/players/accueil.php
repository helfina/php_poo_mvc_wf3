<h1>Accueil</h1>
<!-- afficher jeux -->
<div>
    <div>
        <p><a href="index.php?c=games&m=index"><i class="fas fa-eye" style="color:green;"></i>Afficher les jeux</a></p>
    </div>
</div>
<!-- afficher joueur -->
<div>
    <div>
        <p><a href="index.php?c=players&m=afficher"><i class="fas fa-eye" style="color:green;"></i>Voir les jouers</a></p>
    </div>
</div>
<!-- ajouter jeu -->
<div>
    <div>
        <p><a href="index.php?c=games&m=ajouter"><i class="fas fa-eye" style="color:green;"></i>Ajouter un jeu</a></p>
    </div>
</div>
<!-- ajouter joueur -->
<div>
    <div>
        <p><a href="index.php?c=players&m=ajouter"><i class="fas fa-eye" style="color:green;"></i>Ajouter un joueur</a></p>
    </div>
</div>
<!-- afficher jeux en cours -->
<div>
    <div>
        <p><a href="index.php?c=players&m=afficherContest"><i class="fas fa-eye" style="color:green;"></i>afficher jeux en cours</a></p>
    </div>
</div>
