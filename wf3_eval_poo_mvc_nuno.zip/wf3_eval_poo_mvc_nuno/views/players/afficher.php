<!-- liste des joueurs -->
<h1 class="text-center my-5">liste des joueurs</h1>

<table class="table table-border table-striped">
    <thead class="thead-dark">
        <tr>
            <th>Id</th>
            <th>Email</th>
            <th>Nickname</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($players as $player): ?>
            <tr>
                <td><?=$player['id']?></td>
                <td><?=$player['email']?></td>
                <td><?=$player['nickname']?></td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>