<?=$msgSuccess ?? $msgSuccess?>
<?=$msgError ?? $msgError?>

<h1>Ajouter un joueur</h1>

<form method="post" class="my-5 container">
    <!-- title -->
    <div class="form-floating mb-3">
        <input type="email" name="email" id="email" class="form-control" required value="" >
        <label for="email">Email</label>
    </div>
    <!-- min players -->
    <div class="form-floating mb-3">
        <input type="text" name="nickname" id="nickname" class="form-control" required value="" >
        <label for="nickname">Nickname</label>
    </div>

    <button type="submit" class="btn btn-primary">Ajouter jeu</button>
</form>
