<!-- liste des joueurs -->
<h1 class="text-center my-5">liste des jeux en cours</h1>
<table class="table table-border table-striped">
    <thead class="thead-dark">
        <tr>
            <th>Id</th>
            <th>Email</th>
            <th>Nickname</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($contests as $contest): ?>
        <?php var_dump($contest)?>
            <tr>
                <td><?=$contest['id']?></td>
                <td><?=$contest['email']?></td>
                <td><?=$contest['nickname']?></td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>