<?=$msgSuccess ?? $msgSuccess?>
<?=$msgError ?? $msgError?>

<h1>Ajouter un jeu</h1>

<form action="" method="post" class="my-5 container">
    <!-- title -->
    <div class="form-floating mb-3">
        <input type="text" name="title" id="title" class="form-control" required value="" >
        <label for="title">Titre du jeu</label>
    </div>
    <!-- min players -->
    <div class="form-floating mb-3">
        <input type="text" name="min_players" id="min_players" class="form-control" required value="" >
        <label for="min_players">Nombre minimum de joueurs</label>
    </div>
    <!-- max players -->
    <div class="form-floating mb-3">
        <input type="text" name="max_players" id="max_players" class="form-control" required value="" >
        <label for="max_players">Nombre maximum de joueurs</label>
    </div>

    <button type="submit" class="btn btn-primary">Ajouter jeu</button>
</form>
