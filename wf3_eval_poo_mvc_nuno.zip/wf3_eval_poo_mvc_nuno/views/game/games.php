<!-- liste des jeux disponibles -->
<h1 class="text-center my-5">liste des jeux</h1>
<table class="table table-border table-striped">
    <thead class="thead-dark">
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>min_players</th>
            <th>max_players</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($games as $game): ?>
            <tr>
                <td><?=$game['id']?></td>
                <td><?=$game['title']?></td>
                <td><?=$game['min_players']?></td>
                <td><?=$game['max_players']?></td>
                <td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>
