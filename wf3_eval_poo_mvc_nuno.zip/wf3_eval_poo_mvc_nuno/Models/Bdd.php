<?php
namespace Models;

use PDO;

abstract class Bdd
{
    /**
     * Undocumented function
     *
     * @param string $table
     * @return PDO
     */
    public static function pdo(): PDO
    {
        try {
            return new PDO("mysql:host=localhost;dbname=wf3_php_final_nuno;charset=utf8", "root", "");

        } catch (\Throwable$e) {
            die("<div class='alert alert-danger'>ERROR : " . $e->getMessage()) . "</div>";
        }
    }

    /**
     * Undocumented function
     *
     * @param string $table
     * @return array|null
     */
    public static function selectAllIntoBdd(string $table): ?array
    {
        $pdostatement = self::pdo()->query(" SELECT * FROM $table ");
        if ($pdostatement) {
            return $pdostatement->fetchAll(PDO::FETCH_ASSOC);
        }
        return null;
    }

    /**
     * méthode pour récup les jouers et les jeux vie les id, cette méthode n'est pas terminé
     *
     * @param string $table
     * @return array|null
     */
    public static function selectAllContest(string $table): ?array
    {
        $pdostatement = self::pdo()->query(" SELECT * FROM $table ");
        if ($pdostatement) {
            return $pdostatement->fetchAll(PDO::FETCH_ASSOC);
        }
        return null;
    }

    /**
     * Undocumented function
     *
     * @param array $data
     * @return boolean
     */
    public static function insertIntoGame(array $data): bool
    {
        $pdo = self::pdo();
        extract($data);
        $pdostatement = $pdo->prepare(" INSERT INTO  game (title, min_players, max_players)
                                        VALUES (:title, :min_players, :max_players) ");
        $pdostatement->bindValue(":title", $title);
        $pdostatement->bindValue(":min_players", $min_players);
        $pdostatement->bindValue(":max_players", $max_players);
        return $pdostatement->execute();
    }

    /**
     * Undocumented function
     *
     * @param array $data
     * @return boolean
     */
    public static function insertIntoPlayer(array $data): bool
    {
        $pdo = self::pdo();
        extract($data);
        $pdostatement = $pdo->prepare(" INSERT INTO  player (email, nickname)
                                        VALUES (:email, :nickname) ");
        $pdostatement->bindValue(":email", $email);
        $pdostatement->bindValue(":nickname", $nickname);
        return $pdostatement->execute();
    }

    public static function insertIntoContest(array $data): bool
    {
        $pdo = self::pdo();
        extract($data);
        $pdostatement = $pdo->prepare(" INSERT INTO  contest (game_id, nickname)
                                        VALUES (:email, :nickname) ");
        $pdostatement->bindValue(":email", $categorie);
        $pdostatement->bindValue(":nickname", $categorie);
        return $pdostatement->execute();
    }

    /**
     * Undocumented function
     *
     * @param array $data
     * @param integer $id
     * @return boolean
     */
    public static function updateGame(array $data, int $id): bool
    {
        $pdo = self::pdo();
        extract($data);
        $pdostatement = $pdo->prepare(" UPDATE game  SET title = :title, min_players = :min_players, max_players = :max_players WHERE id = :id");
        $pdostatement->bindValue(":title", $categorie);
        $pdostatement->bindValue(":min_players", $categorie);
        $pdostatement->bindValue(":max_players", $categorie);
        $pdostatement->bindValue(":id", $id);
        return $pdostatement->execute();
    }

    /**
     * Undocumented function
     *
     * @param string $table
     * @param integer $id
     * @return boolean
     */
    public static function delete(string $table, int $id): bool
    {
        $req = self::pdo()->query(" DELETE FROM $table WHERE id = $id ");
        return $req;
    }

}
