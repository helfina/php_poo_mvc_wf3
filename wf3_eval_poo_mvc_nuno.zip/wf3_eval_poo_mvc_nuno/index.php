<?php

require "autoloader.php";

$controleur = $_GET['c'] ?? 'players';
$method = $_GET['m'] ?? 'index';
$id = $_GET['i'] ?? null;

$nomClasse = "Controllers\\" . ucfirst($controleur) . "Controller";

$controleur = new $nomClasse;
$controleur->$method($id);
