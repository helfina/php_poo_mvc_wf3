<?php
namespace Controllers;

abstract class ControllerBase
{
    public function render($vue, array $parametresVue = [])
    {
        extract($parametresVue);
        include "views/header.inc.php";
        include "views/$vue";
        include "views/footer.inc.php";
    }
}
