<?php
namespace Controllers;

use Models\Bdd;

class GamesController extends ControllerBase
{
    /**
     * Undocumented function
     *
     * @return void
     */
    public function index()
    {
        $games = Bdd::selectAllIntoBdd('game');
        return $this->render("game/games.php", ["games" => $games]);
    }

    /**
     * Undocumented function
     *
     * @return void
     */
    public function ajouter()
    {
        if ($_POST) {
            var_dump($_POST);
            // TODO : validation du formulaire
            if (Bdd::insertIntoGame($_POST)) {
                $msgSuccess = "<div class='alert alert-success'>Le nouveau produit a bien été inséré</div>";
            } else {
                $msgError = "<div class='alert alert-danger'>Erreur lors de l'insertion en bdd</div>";
            }
        }
        return $this->render("game/form.html.php");
    }

}
