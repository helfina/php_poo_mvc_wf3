<?php
namespace Controllers;

use Models\Bdd;

class PlayersController extends ControllerBase
{
    public function index()
    {
        $players = Bdd::selectAllIntoBdd('player');
        return $this->render("players/accueil.php", ["players" => $players]);
    }

    public function ajouter()
    {
        if (!empty($_POST)) {
            // TODO : validation du formulaire
            if (Bdd::insertIntoPlayer($_POST)) {
                $msgSuccess = "<div class='alert alert-success'>Le nouveau joueur a bien été inséré</div>";
            } else {
                $msgError = "<div class='alert alert-danger'>Erreur lors de l'insertion en bdd</div>";
            }
        }
        return $this->render("players/form.html.php");
    }

    public function afficher()
    {
        $players = Bdd::selectAllIntoBdd('player');
        return $this->render("players/afficher.php", ["players" => $players]);
    }

    public function afficherContest()
    {
        $contests = Bdd::selectAllContest('player_contest');
        return $this->render("players/afficher.php", ["contests" => $contests]);
    }

}
