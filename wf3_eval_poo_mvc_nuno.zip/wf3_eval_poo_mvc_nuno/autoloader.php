<?php

function chargementClasse($class)
{
    $class = str_replace("\\", DIRECTORY_SEPARATOR, $class);
    require "$class.php";
}

spl_autoload_register("chargementClasse");

// class Autoloader
// {
//     /**
//      * register function
//      *
//      * @return void
//      */
//     public static function register(): void
//     {
//         spl_autoload_register([__CLASS__, "autoload"]);
//     }

//     /**
//      * autoload function
//      *
//      * @param string $class
//      * @return void
//      */
//     public static function autoload(string $class): void
//     {
//         //get the entire namespace of the class
//         $class = str_replace(__NAMESPACE__ . '\\', '', $class);

//         // replace '\' by '/'
//         $class = str_replace("\\", '/', $class);

//         // file path
//         $file = __DIR__ . '/' . $class . '.php';

//         var_dump(__DIR__ . '/' . $class . '.php');

//         // if file exist
//         if (file_exists($file)) {
//             require_once $file;
//         } else {
//             echo "<div class='alert alert-danger'>Error 404 ********</div>";
//         }
//     }
// }
