<?php

namespace Controleurs; 

class ClientControleur{

    public function index(){
        include "vues/header.html.php";
        echo "PAGE EN CONSTRUCTION";
        include "vues/footer.html.php";

    }
}